<div class="alert alert-prymary" role="alert">
    <h3>Seja bem vindo</h3>
</div>