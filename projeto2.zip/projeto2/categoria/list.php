<div class="alert alert-warning" role="alert">
    <h3>Listar categoria</h3>
</div>

<a href="?p=categoria/add" title="Add categoria">+ Categoria</a>