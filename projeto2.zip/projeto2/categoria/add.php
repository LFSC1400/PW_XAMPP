<div class="alert alert-warning" role="alert">
    <h3>Adicionar categoria</h3>
</div>

<a href="?p=categoria/list" title="listar categoria">Voltar</a>